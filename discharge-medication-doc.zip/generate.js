const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
        AlignmentType, BorderStyle, WidthType, ShadingType, VerticalAlign } = require('docx');
const fs = require('fs');

// ==================== 通用配置 ====================
const HOSPITAL_NAME = "XX医院";  // 修改为你的医院名称

// 边框样式
const borderStyle = { style: BorderStyle.SINGLE, size: 1, color: "000000" };
const borders = { top: borderStyle, bottom: borderStyle, left: borderStyle, right: borderStyle };

// 姓名脱敏：姓XX（原姓名去掉姓后，几个字就几个X）
function maskName(name) {
  const surname = name[0];
  const rest = name.slice(1);
  const xCount = rest.replace(/\*/g, '').length + (rest.match(/\*/g) || []).length;
  return surname + 'X'.repeat(xCount);
}

// ==================== 在此填写患者数据 ====================
const patients = [
  // 示例患者 — 按此格式添加更多患者
  {
    name: "张*三", gender: "男", age: "65岁", weight: "70kg", dept: "心内科",
    admissionNo: "123456", admissionDate: "2026-01-01", dischargeDate: "2026-01-07",
    phone: "138****8888", allergy: "无", bed: "12-34",
    diagnosis: "1、冠心病 2、高血压2级 3、2型糖尿病",
    pharmacistNotes: {
      diet: "低盐低脂饮食，每日盐摄入不超过6g。多食蔬菜水果，限制高糖食物。",
      lifestyle: "戒烟限酒，适度运动（如散步30分钟/日），避免剧烈运动和情绪激动。",
      medication: "阿司匹林每日1次早餐前服用，不可随意停药。降压药每日固定时间服用。",
      missed: "阿司匹林漏服：若当日想起立即补服；次日想起则跳过，勿双倍服用。",
      followup: "出院后1周至心内科门诊复诊，复查血常规、肝肾功能、血脂。"
    },
    medicines: [
      {
        name: "阿司匹林肠溶片", spec: "100mg*30片/盒",
        purpose: "抗血小板聚集，预防心肌梗死和脑卒中",
        dosage: "口服，一次100mg，每日1次，早餐前服用",
        notes: "1. 肠溶片应空腹服用\n2. 观察有无牙龈出血、黑便\n3. 手术前需停药并告知医师",
        remark: "需长期服用"
      },
      {
        name: "氨氯地平片", spec: "5mg*28片/盒",
        purpose: "钙通道阻滞剂，降低血压",
        dosage: "口服，一次5mg，每日1次，晨起服用",
        notes: "1. 可能引起踝部水肿、头痛\n2. 不可突然停药\n3. 定期监测血压",
        remark: "长期规律服用"
      }
    ]
  }
  // 添加更多患者...
];

// ==================== 通用函数（无需修改）====================

function createHeaderCell(text, width) {
  return new TableCell({
    borders,
    width: { size: width, type: WidthType.DXA },
    shading: { fill: "E8E8E8", type: ShadingType.CLEAR },
    verticalAlign: VerticalAlign.CENTER,
    margins: { top: 60, bottom: 60, left: 80, right: 80 },
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text, bold: true, font: "宋体", size: 20 })]
    })]
  });
}

function createDataCell(text, width) {
  const lines = text.split('\n');
  return new TableCell({
    borders,
    width: { size: width, type: WidthType.DXA },
    verticalAlign: VerticalAlign.TOP,
    margins: { top: 60, bottom: 60, left: 80, right: 80 },
    children: lines.map(line => new Paragraph({
      spacing: { after: 40 },
      children: [new TextRun({ text: line, font: "宋体", size: 18 })]
    }))
  });
}

function createMedicineTable(medicines) {
  const headerRow = new TableRow({
    children: [
      createHeaderCell("药品名称", 1165),
      createHeaderCell("规格", 1100),
      createHeaderCell("用药目的", 1800),
      createHeaderCell("用法用量", 1500),
      createHeaderCell("注意事项", 3200),
      createHeaderCell("备注", 1200)
    ]
  });

  const dataRows = medicines.map(med =>
    new TableRow({
      children: [
        createDataCell(med.name, 1100),
        createDataCell(med.spec, 1100),
        createDataCell(med.purpose, 1750),
        createDataCell(med.dosage, 1450),
        createDataCell(med.notes, 3150),
        createDataCell(med.remark || "", 1150)
      ]
    })
  );

  return new Table({
    width: { size: 10000, type: WidthType.DXA },
    columnWidths: [1100, 1100, 1750, 1450, 3150, 1150],
    rows: [headerRow, ...dataRows]
  });
}

// ==================== 文档生成核心函数 ====================

async function generateDocument(patient, options = {}) {
  const displayName = maskName(patient.name);

  const dDate = patient.dischargeDate;
  const dateParts = dDate.split('-');
  const dateStr = `${dateParts[0]}年${parseInt(dateParts[1])}月${parseInt(dateParts[2])}日`;

  const doc = new Document({
    styles: { default: { document: { run: { font: "宋体", size: 21 } } } },
    sections: [{
      properties: {
        page: {
          margin: { top: 720, right: 720, bottom: 720, left: 720 },
          size: { width: 11906, height: 16838 }
        }
      },
      children: [
        // 标题
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
          children: [new TextRun({ text: `${HOSPITAL_NAME}出院用药教育记录表`, bold: true, font: "黑体", size: 36 })]
        }),

        // 基本信息 + 疾病诊断
        new Table({
          width: { size: 10000, type: WidthType.DXA },
          columnWidths: [1200, 8800],
          rows: [
            new TableRow({
              children: [
                new TableCell({
                  borders,
                  width: { size: 1200, type: WidthType.DXA },
                  shading: { fill: "E8E8E8", type: ShadingType.CLEAR },
                  verticalAlign: VerticalAlign.CENTER,
                  children: [new Paragraph({ children: [new TextRun({ text: "基本信息", bold: true, font: "宋体", size: 22 })] })]
                }),
                new TableCell({
                  borders,
                  width: { size: 8800, type: WidthType.DXA },
                  children: [new Paragraph({
                    spacing: { before: 60, after: 60 },
                    children: [new TextRun({
                      text: `姓名：${displayName}  性别：${patient.gender}  年龄：${patient.age}  体重：${patient.weight}  科室：${patient.dept}${patient.bed ? '  床号：' + patient.bed : ''}  住院号：${patient.admissionNo}  入院时间：${patient.admissionDate}  出院时间：${patient.dischargeDate}  联系电话：${patient.phone}  过敏史：${patient.allergy}`,
                      font: "宋体", size: 20
                    })]
                  })]
                })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({
                  borders,
                  width: { size: 1200, type: WidthType.DXA },
                  shading: { fill: "E8E8E8", type: ShadingType.CLEAR },
                  verticalAlign: VerticalAlign.CENTER,
                  children: [new Paragraph({ children: [new TextRun({ text: "疾病诊断", bold: true, font: "宋体", size: 22 })] })]
                }),
                new TableCell({
                  borders,
                  width: { size: 8800, type: WidthType.DXA },
                  children: [new Paragraph({
                    spacing: { before: 60, after: 60 },
                    children: [new TextRun({ text: patient.diagnosis, font: "宋体", size: 20 })]
                  })]
                })
              ]
            })
          ]
        }),

        new Paragraph({ spacing: { after: 200 }, children: [] }),

        // 药品信息标题栏
        new Table({
          width: { size: 10000, type: WidthType.DXA },
          columnWidths: [10000],
          rows: [
            new TableRow({
              children: [
                new TableCell({
                  borders,
                  shading: { fill: "D9EDF7", type: ShadingType.CLEAR },
                  children: [new Paragraph({
                    alignment: AlignmentType.CENTER,
                    spacing: { before: 80, after: 80 },
                    children: [new TextRun({ text: "药品信息", bold: true, font: "黑体", size: 24 })]
                  })]
                })
              ]
            })
          ]
        }),

        // 药品信息表格
        createMedicineTable(patient.medicines),

        new Paragraph({ spacing: { before: 300 }, children: [] }),

        // 临床药师交代其他事宜
        new Table({
          width: { size: 10000, type: WidthType.DXA },
          columnWidths: [1600, 8400],
          rows: [
            new TableRow({
              children: [
                new TableCell({
                  borders,
                  width: { size: 1600, type: WidthType.DXA },
                  verticalAlign: VerticalAlign.CENTER,
                  shading: { fill: "E8E8E8", type: ShadingType.CLEAR },
                  children: [
                    new Paragraph({
                      alignment: AlignmentType.CENTER,
                      spacing: { before: 40, after: 20 },
                      children: [new TextRun({ text: "临床药师交代其他", font: "宋体", size: 19, bold: true })]
                    }),
                    new Paragraph({
                      alignment: AlignmentType.CENTER,
                      spacing: { before: 0, after: 40 },
                      children: [new TextRun({ text: "事宜", font: "宋体", size: 19, bold: true })]
                    })
                  ]
                }),
                new TableCell({
                  borders,
                  width: { size: 8400, type: WidthType.DXA },
                  children: [
                    new Paragraph({ spacing: { before: 80, after: 40 }, children: [new TextRun({ text: "饮食指导：", font: "宋体", size: 18, bold: true })] }),
                    new Paragraph({ spacing: { before: 0, after: 80 }, indent: { firstLine: 200 }, children: [new TextRun({ text: patient.pharmacistNotes.diet, font: "宋体", size: 18, color: "333333" })] }),
                    new Paragraph({ spacing: { before: 0, after: 40 }, children: [new TextRun({ text: "生活方式指导：", font: "宋体", size: 18, bold: true })] }),
                    new Paragraph({ spacing: { before: 0, after: 80 }, indent: { firstLine: 200 }, children: [new TextRun({ text: patient.pharmacistNotes.lifestyle, font: "宋体", size: 18, color: "333333" })] }),
                    new Paragraph({ spacing: { before: 0, after: 40 }, children: [new TextRun({ text: "用药管理：", font: "宋体", size: 18, bold: true })] }),
                    new Paragraph({ spacing: { before: 0, after: 80 }, indent: { firstLine: 200 }, children: [new TextRun({ text: patient.pharmacistNotes.medication, font: "宋体", size: 18, color: "333333" })] }),
                    new Paragraph({ spacing: { before: 0, after: 40 }, children: [new TextRun({ text: "漏服药物：", font: "宋体", size: 18, bold: true })] }),
                    new Paragraph({ spacing: { before: 0, after: 80 }, indent: { firstLine: 200 }, children: [new TextRun({ text: patient.pharmacistNotes.missed, font: "宋体", size: 18, color: "333333" })] }),
                    new Paragraph({ spacing: { before: 0, after: 40 }, children: [new TextRun({ text: "术后随访：", font: "宋体", size: 18, bold: true })] }),
                    new Paragraph({ spacing: { before: 0, after: 80 }, indent: { firstLine: 200 }, children: [new TextRun({ text: patient.pharmacistNotes.followup, font: "宋体", size: 18, color: "333333" })] })
                  ]
                })
              ]
            })
          ]
        }),

        new Paragraph({ spacing: { before: 200 }, children: [] }),

        // 知晓度 + 患者签名
        new Table({
          width: { size: 10000, type: WidthType.DXA },
          columnWidths: [1165, 8835],
          rows: [
            new TableRow({
              children: [
                new TableCell({
                  borders,
                  width: { size: 1165, type: WidthType.DXA },
                  verticalAlign: VerticalAlign.CENTER,
                  rowSpan: 2,
                  children: [new Paragraph({
                    alignment: AlignmentType.CENTER,
                    spacing: { before: 60, after: 60 },
                    children: [new TextRun({ text: "患者确认", font: "宋体", size: 19, bold: true })]
                  })]
                }),
                new TableCell({
                  borders,
                  width: { size: 8835, type: WidthType.DXA },
                  children: [new Paragraph({
                    spacing: { before: 60, after: 60 },
                    children: [new TextRun({ text: "知晓度：□很好   ☑好   □一般   □差   □很差", font: "宋体", size: 19 })]
                  })]
                })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({
                  borders,
                  width: { size: 8835, type: WidthType.DXA },
                  children: [new Paragraph({
                    spacing: { before: 60, after: 80 },
                    children: [new TextRun({ text: "患者或家属签名：__________________", font: "宋体", size: 19 })]
                  })]
                })
              ]
            })
          ]
        }),

        new Paragraph({ spacing: { before: 100 }, children: [] }),

        // 意见
        new Table({
          width: { size: 10000, type: WidthType.DXA },
          columnWidths: [1165, 8835],
          rows: [
            new TableRow({
              children: [
                new TableCell({
                  borders,
                  width: { size: 1165, type: WidthType.DXA },
                  verticalAlign: VerticalAlign.CENTER,
                  shading: { fill: "F5F5F5", type: ShadingType.CLEAR },
                  children: [new Paragraph({
                    alignment: AlignmentType.CENTER,
                    spacing: { before: 60, after: 60 },
                    children: [new TextRun({ text: "意见", font: "宋体", size: 19, bold: true })]
                  })]
                }),
                new TableCell({
                  borders,
                  width: { size: 8835, type: WidthType.DXA },
                  children: [new Paragraph({
                    spacing: { before: 60, after: 60 },
                    children: [
                      new TextRun({ text: "意见：□无   □有   具体：", font: "宋体", size: 19 }),
                      new TextRun({ text: "_______________________________", font: "宋体", size: 19 })
                    ]
                  })]
                })
              ]
            })
          ]
        }),

        // 随访日期 + 药师签名（留空）
        new Table({
          width: { size: 10000, type: WidthType.DXA },
          columnWidths: [10000],
          rows: [
            new TableRow({
              children: [
                new TableCell({
                  borders,
                  children: [
                    new Paragraph({
                      spacing: { before: 80, after: 40 },
                      children: [new TextRun({ text: `建议出院随访日期：____年____月____日`, font: "宋体", size: 19 })]
                    }),
                    new Paragraph({
                      spacing: { before: 40, after: 80 },
                      children: [
                        new TextRun({ text: "用药教育药师签名：", font: "宋体", size: 19 }),
                        new TextRun({ text: "________________", font: "宋体", size: 19 }),
                        new TextRun({ text: `                              日期：${dateStr}`, font: "宋体", size: 19 })
                      ]
                    })
                  ]
                })
              ]
            })
          ]
        })
      ]
    }]
  });

  const buffer = await Packer.toBuffer(doc);
  const safeName = displayName.replace(/\*/g, '');
  const fileName = `出院用药教育记录表_${safeName}_${patient.admissionNo}.docx`;
  const outputPath = options.outputDir || process.cwd();
  fs.writeFileSync(`${outputPath}/${fileName}`, buffer);
  console.log(`✅ 已生成: ${fileName}`);
  return fileName;
}

// ==================== 主函数 ====================

async function main() {
  console.log("📋 开始生成出院用药教育文档...\n");
  console.log(`📊 共 ${patients.length} 个患者\n`);

  for (let i = 0; i < patients.length; i++) {
    console.log(`--- 正在处理第 ${i + 1}/${patients.length} 位患者: ${patients[i].name} → ${maskName(patients[i].name)} ---`);
    await generateDocument(patients[i]);
  }

  console.log(`\n✨ 全部完成！共生成 ${patients.length} 份出院用药教育记录表`);
}

main().catch(console.error);
