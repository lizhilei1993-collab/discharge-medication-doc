# 出院用药教育记录表批量生成器

基于 Node.js + docx 库，从结构化患者数据批量生成标准格式的出院用药教育记录表 Word 文档。

## 特性

- 从 JSON 患者数据批量生成 `.docx` 文档
- 自动姓名脱敏（姓XX，几个字就几个X）
- 药师签名栏留空（手写签名区域）
- 包含：基本信息、疾病诊断、药品信息表、5类药师交代、患者确认、意见栏、随访日期
- 医院名称可配置，无硬编码个人信息

## 快速开始

```bash
# 克隆仓库
git clone https://github.com/yourname/discharge-medication-doc.git
cd discharge-medication-doc

# 安装依赖
npm install

# 编辑 generate.js 中的患者数据，然后运行
npm start
```

## 文档结构

| 区域 | 内容 |
|------|------|
| 标题 | `{医院名}出院用药教育记录表` |
| 基本信息 | 姓名(脱敏)、性别、年龄、体重、科室、床号、住院号、入出院时间、电话、过敏史 |
| 疾病诊断 | 出院诊断全文 |
| 药品信息 | 6列表格：药品名称、规格、用药目的、用法用量、注意事项、备注 |
| 临床药师交代 | 5类：饮食指导 / 生活方式指导 / 用药管理 / 漏服药物 / 术后随访 |
| 患者确认 | 知晓度勾选 + 患者或家属签名栏 |
| 意见 | □无 / □有 + 具体意见填写栏 |
| 随访+签名 | 建议出院随访日期 + **药师签名留空** + 日期(=出院日期) |

## 患者数据格式

在 `generate.js` 中编辑 `patients` 数组：

```javascript
{
  name: "张*三",
  gender: "男",
  age: "65岁",
  weight: "70kg",
  dept: "心内科",
  admissionNo: "123456",
  admissionDate: "2026-01-01",
  dischargeDate: "2026-01-07",
  phone: "138****8888",
  allergy: "无",
  bed: "12-34",
  diagnosis: "1、冠心病 2、高血压2级",
  pharmacistNotes: {
    diet: "低盐低脂饮食...",
    lifestyle: "戒烟限酒...",
    medication: "阿司匹林每日1次...",
    missed: "漏服后立即补服...",
    followup: "出院后1周复诊..."
  },
  medicines: [
    {
      name: "阿司匹林肠溶片",
      spec: "100mg*30片/盒",
      purpose: "抗血小板聚集",
      dosage: "口服，一次100mg，每日1次",
      notes: "1. 空腹服用\n2. 观察出血征象",
      remark: "需长期服用"
    }
  ]
}
```

## 配置医院名称

修改脚本顶部的常量：

```javascript
const HOSPITAL_NAME = "XX医院";  // 修改为你的医院名称
```

## 依赖

- Node.js >= 16
- docx ^9.0.0

## License

MIT
